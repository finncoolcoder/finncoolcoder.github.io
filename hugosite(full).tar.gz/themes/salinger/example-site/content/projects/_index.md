---
title: "Featured guides 🤖"
weight: 10
---
Here a category of guide. This is a random sentence, actually. **Rich text** is allowed.