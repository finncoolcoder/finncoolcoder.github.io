---
title: "02 Linux.md"
date: 2024-10-03T19:52:29-04:00
slug: 2024-10-03-02-linux.md
type: posts
draft: false
categories:
  - default
tags:
  - default
---

![my alt text](https://cdn.bsky.app/img/feed_fullsize/plain/did:plc:p2y466m63svxixp56gglbrlm/bafkreigzbyxw7spkpalbgoaphsdeztutkx5yktkwffgxlzl3zqfpai2mza@jpeg)

![my alt text](/linuxreasons.jpg)

Linux is a real pain. It's finnicky, It takes a long time to configure and almost nothing
works right out of the box. When you try to install a program there are about 5 ways
to do it, some of which are supported by said program and some, completeley bootleg.
There are literally hundreds  of different distrobutions with varying security,
use-cases, and preinstalled package managers. The GUI can change too, going from
non-traditional things like a 3d GUI all the way to windows and OSX recreations 
that are surprising accurate. One might wonder why a person goes through all this struggle
instead of just picking a normal, bloated, corporate, locked down operating system like
a normal person. The answer is simple: Because linux makes you feel like a badass. 
GNU/Linux is a culmination of the collective brains of literally thousands upon thousands
of people; from all over the world, from numerous backrounds and fields of work.
Linux is the official operating system for governments around the world and yet still it sucks.
That's why some people use it, they enjoy a challenge. Arch linux as a philosophy
can be attributed to this natural human desire to do things the hard way in the interest
of being cool. Wheather or not spending "Unneccesary" time fiddling with you're settings
for hours just trying to make a screen recording is attrractive or "cool" it is certainly 
educational. That is the primary reason I think people should use linux.
It is just difficult enough to learn things but just common enough to daily drive.
When you sit down and say "I will learn this." it is a different type of learning
compared to that which happens when you are in the center of a project and need to 
figure this out or all you're work will be worthless. That is the kind of learning
that will really stick with you-it's accosiated with emotion. It is not the blank 
feelingless memorization of commands and phrases and filesystems. It is the quick skimming
of documentation, gleaning just enough information to complete the task, nothing more.
If you never have problems on you're operating system, you will never learn about it.
And if you never learn about it you will never be able to fix it if something does go wrong.
There is a quote by stephen hawking along the lines of "A society that relies on technologys it
does not understand is suicidal." Unfortunatley this is already a widespread problem 
in our world. The people that understand the computers are consulted far too often,
experimentation is left out of the equation. Hell, even googling you're problem is 
out of the equation. This can be explained for high importance tasks that must not fail.
However it is suprising how many people ask someone who is "techy" before they even
google their issue. When you use linux there is such a constant influx of issues, problems,
and general things that need troubleshooting; that to google every problem, is imposible.
Experimentation, and even just plain simple reading the documentation come back into play.
People forget there are entire manuals written online for almost every piece of software. 
These are free to read and in the process become more adept at using that software.
This is the reason that linux is as popular as it is, it's not the customization, 
it's not the open source nature; it's the attitude that one develops from using something
that is powerful and imperfect-almost like magic and religion. Mainstream operating systems
are like following a religion: you believe in it until it breaks and then you
talk to somebody else about it. Whereas GNU/Linux is like being a Rabbi or a monk. 
You understand so much more and you encounter these things for long periods of time
daily. Not to say linux is a religion but it certainly has the capacity to change
you as a person. Food for thought indeed...
