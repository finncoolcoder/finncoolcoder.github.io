+++
title = 'Why Everyone Needs a Personal Website'
date = 2024-10-06T13:38:18-04:00
draft = false
+++
## they don't but it is better than having a social media.
chances are you're social media is useless. It helps nobody and is completley useless. It is a collection of silly selfies and screenshots from other
people's twitter posts that were mildly amusing. There is no value. I am very hypocritical by writing this post. I have a youtube channel and a blusky
these are plauged by the same things that I just described. Without an algorithm, I feel no motivation to make my posts click-baity. There
is no reason for me to make content that will theoretically "do well" on the platform. Only to make whatever I feel like. The only anylitics
I have installed on this site is that which neocities automatically does. This removes the motivation to make the most widely aprreciated content
with hundreds of pictures and SEO friendly keywords and hashtags.
My second point is that writing as a medium allows for breakdowns of you're projects. this is especially useful if you are doing something
technical that is not well documented. YOU have a good chance of becoming that lucky search result that explains exactly what the problem is
and how to fix it. How is you're instagram helping anybody with anything?
that's it folks im sick of writing.
