---
title: "Shell Script Video"
date: 2024-10-03T20:20:58-04:00
slug: 2024-10-03-shellscriptvideo
type: posts
draft: false
categories:
  - default
tags:
  - default
---
[Link Here](https://www.youtube.com/watch?v=GR-96xOM8h4)


