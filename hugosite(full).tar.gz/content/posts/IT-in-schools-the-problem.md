+++
title = 'IT in Schools part 1: the Problem'
date = 2024-10-19T18:06:23-04:00
draft = false
categories = ["blog"]
tags = ["rant", "school"]
+++
When the system punishes for doing something helpful. That absolutely 
enrages me. The other day, I was puttering around my highschool and I
found my old USB stick with KDE neon on it. I had the idea that I would
see if it would work on the computers in the computer lab. Surprisingly,
after a bit of fiddling, it did work-flawlessly-without a hitch. The process
could be simply followed by the most tech-adverse senior citezen. 
I was alarmed, I was unhappy with the ease of this exploit and that 
I had never thought of it before. I could have used this to browse the
uncensored internet for at least a month before anyone noticed; but instead
I made the descision to tell the IT department about the 
vulnerability. And without much hesitation and discussion, and with a warning
not to do it again I was let off free. Then, a week later I brought my 
flipper zero to school(so I could try to sell it to the principal's kid)
and he used a badusb script on one of the beforementioned computers.
FOUR WHOLE DAYS after that, the principal calls home, says that IT had
talked to me already and that if I did something like this again I would be in trouble.
Perfectly reasonable, however what irked me was the ambiguity of 
which problem was more problematic, the insane delay of response, and the
sheer lack of ability to understand exactly what a flipper zero can do.
Firstly the ambiguity, this was a big one: the principal bundled two separate
things I did and put them together into one single event, despite
the first problem seemingly already having been resolved.
Additionally this lumping of issues that had happened with weeks in-between
causes a general lack of understanding of either event. The principal 
said she was afraid the flipper zero could steal the key-card-code to
enter the school-even though that is a blatant lie. It reminds me of the 
cynical canadian lawmakers who banned it, claiming it can steal cars
without actually explaining the scientific limitations behind what 
it can actually do(and how it does so). So what does this say about 
the system of IT restictions in american public schools?
Well to put it briefly: Creativity and help are not appreciated,
and those with a determination to "move fast and break things" are 
punished for what should be an aid to the general good.
