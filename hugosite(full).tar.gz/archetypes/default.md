+++
title = '{{ replace .File.ContentBaseName "-" " " | title }}'
date = {{ .Date }}
draft = false
categories:
  - blog
tags:
  - rant
  - linux
+++
